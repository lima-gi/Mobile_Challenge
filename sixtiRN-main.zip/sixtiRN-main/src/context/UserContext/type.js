import React from 'react';

const UserContext = React.createContext({
  user: [
    {
      cpf: '',
      doctor: '',
      id: '',
    },
  ],
  setUser: item => {},
  updateUser: item => {},
  deleteUser: item => {},
  clearUser: () => {},
});

export default UserContext;
