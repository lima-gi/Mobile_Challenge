import React, {useReducer} from 'react';

import UserContext from './type';

import doctors from '../../json/doctor.json';
import clients from '../../json/clients.json';

const defaultCartState = {
  user: [],
};

const cartReducer = (state, action) => {
  if (action.type === 'ADD') {
    const existingUser = state.user.find(item => item.cpf === action.item.cpf);
    const existingDoctor = doctors.data.find(
      item => item.id === action.item.doctor,
    );
    const existingClient = clients.data.find(
      item => item.id === action.item.id,
    );

    if (existingUser) {
      alert('User Already Exists!');
      return {
        user: state.user,
      };
    }

    if (!existingDoctor) {
      alert('Doctor not Exists!');
      return {
        user: state.user,
      };
    }

    if (!existingClient) {
      alert('Client not Exists!');
      return {
        user: state.user,
      };
    }

    const updatedItems = state.user.concat(action.item);

    alert('Created User!');

    return {
      user: updatedItems,
    };
  } else if (action.type === 'UPDATE') {
    const existingUserIndex = state.user.findIndex(
      item => item.cpf === action.item.cpf,
    );

    const existingUserItem = state.user[existingUserIndex];

    const existingDoctor = doctors.data.find(
      item => item.id === action.item.doctor,
    );
    const existingClient = clients.data.find(
      item => item.id === action.item.id,
    );

    if (!existingDoctor) {
      alert('Doctor not Exists!');
      return {
        user: state.user,
      };
    }

    if (!existingClient) {
      alert('Client not Exists!');
      return {
        user: state.user,
      };
    }

    if (existingUserItem) {
      const updatedItem = action.item;

      const updatedItems = [...state.user];
      updatedItems[existingUserIndex] = updatedItem;

      return {
        user: updatedItems,
      };
    } else {
      alert('User not found!');
      return {
        user: state.user,
      };
    }
  } else if (action.type === 'DELETE') {
    const existingUserIndex = state.user.findIndex(
      item => item.cpf === action.item.cpf,
    );

    const existingUserItem = state.user[existingUserIndex];

    if (!existingUserItem) {
      alert('User not found');
      return {
        user: state.user,
      };
    }

    const updatedItems = state.user.filter(
      item => item.cpf !== action.item.cpf,
    );

    alert('Deleted User!');

    return {
      user: updatedItems,
    };
  } else if (action.type === 'CLEAR') {
    return defaultCartState;
  }
  return defaultCartState;
};

const UserProvider = props => {
  const [cartState, dispatchCartAction] = useReducer(
    cartReducer,
    defaultCartState,
  );

  const setUser = item => {
    dispatchCartAction({type: 'ADD', item: item});
  };

  const updateUser = item => {
    dispatchCartAction({type: 'UPDATE', item: item});
  };

  const deleteUser = item => {
    dispatchCartAction({type: 'DELETE', item: item});
  };

  const clearUser = () => {
    dispatchCartAction({type: 'CLEAR'});
  };

  const cartContext = {
    user: cartState.user,
    setUser,
    updateUser,
    deleteUser,
    clearUser,
  };

  return (
    <UserContext.Provider value={cartContext}>
      {props.children}
    </UserContext.Provider>
  );
};

export default UserProvider;
