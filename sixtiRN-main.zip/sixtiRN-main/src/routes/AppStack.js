import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import Login from '../screens/Login';
import ClientTabs from './ClientTabs';
import CreateNewMatch from '../screens/CreateNewMatch';
import AlterClientValue from '../screens/AlterClientValue';

const {Navigator, Screen} = createNativeStackNavigator();

const AppStack = () => {
  return (
    <NavigationContainer>
      <Navigator screenOptions={{headerShown: false}}>
        <Screen name="Login" component={Login} />
        <Screen name="ClientTabs" component={ClientTabs} />
        <Screen name="CreateNewMatch" component={CreateNewMatch} />
        <Screen name="AlterClientValue" component={AlterClientValue} />
      </Navigator>
    </NavigationContainer>
  );
};

export default AppStack;
