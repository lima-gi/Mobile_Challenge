import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';

import Home from '../screens/Home';
import Notifications from '../screens/Notifications';

const {Navigator, Screen} = createBottomTabNavigator();

function ClientTabs() {
  return (
    <Navigator
      tabBarOptions={{
        style: {
          elevation: 0,
          shadowOpacity: 0,
          height: 64,
        },

        tabStyle: {
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
        },

        iconStyle: {
          flex: 0,
          width: 20,
          height: 30,
        },

        labelStyle: {
          fontSize: 13,
          marginLeft: 16,
        },

        inactiveBackgroundColor: '#fafafc',
        activeBackgroundColor: '#ebebf5',
        inactiveTintColor: '#c1bccc',
        activeTintColor: '#32264b',
      }}>
      <Screen
        name="Home"
        component={Home}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({color, size, focused}) => {
            return (
              <Ionicons
                name="home"
                size={15}
                color={focused ? '#DE0C4B' : color}
              />
            );
          },
        }}
      />
      <Screen
        name="Notifications"
        component={Notifications}
        options={{
          tabBarLabel: 'Notifications',
          tabBarIcon: ({color, size, focused}) => {
            return (
              <Ionicons
                name="notifications"
                style={25}
                color={focused ? '#DE0C4B' : color}
              />
            );
          },
        }}
      />
    </Navigator>
  );
}

export default ClientTabs;
