import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  backgroundStyle: {
    backgroundColor: '#E2E1E1',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    backgroundColor: '#89EAFF',
    width: '40%',
    borderRadius: 15,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: 'black',
  },
  title: {
    fontSize: 40,
    color: 'black',
  },
  view: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 20,
  },
  clientImage: {
    height: 120,
    width: 120,
    borderRadius: 60,
    margin: 20,
  },
  clientDataView: {
    alignItems: 'center',
  },
  clientDataTitle: {
    fontSize: 32,
    fontWeight: '700',
  },
  clientDataSubTitle: {
    fontSize: 26,
  },
  contentText: {
    fontSize: 20,
    marginBottom: 10,
  },
  ButtonsView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});

export default styles;
