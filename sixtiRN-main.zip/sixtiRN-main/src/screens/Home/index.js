import {useNavigation} from '@react-navigation/native';
import React, {useState, useContext, useEffect} from 'react';
import {SafeAreaView, Text, TouchableOpacity, View, Image} from 'react-native';

import UserContext from '../../context/UserContext/type';
import styles from './styles';

import AsyncStorage from '@react-native-community/async-storage';

import clients from '../../json/clients.json';

const Home = () => {
  const userCtx = useContext(UserContext);

  const [client, setClient] = useState({});

  const {navigate} = useNavigation();
  const backHandle = async () => {
    navigate('Login');
  };

  const deleteUser = async () => {
    const cpf = await AsyncStorage.getItem('cpfUser');

    const data = {
      cpf,
    };

    userCtx.deleteUser(data);
    navigate('Login');
  };

  useEffect(() => {
    const userProfile = async () => {
      const clientId = await AsyncStorage.getItem('clientId');

      const clientObject = clients.data.find(item => item.id === clientId);

      setClient(clientObject);
    };

    userProfile();
  }, []);

  return (
    <SafeAreaView style={styles.backgroundStyle}>
      <View style={styles.view}>
        <View style={styles.clientDataView}>
          <Image source={{uri: client.photo}} style={styles.clientImage} />
          <Text style={styles.clientDataTitle}> {client.name} </Text>
          <Text style={styles.clientDataSubTitle}> {client.age} </Text>
        </View>
        <View>
          <Text style={styles.contentText}>
            Symptoms: {client.symptoms && client.symptoms.join(', ')}
          </Text>
          <Text style={styles.contentText}>
            Hearth Rate: {client.hearthRate} bpm
          </Text>
          <Text style={styles.contentText}>
            Temperature: {client.temperature} C
          </Text>
          <Text style={styles.contentText}>
            Blood Pressure: {client.bloodPressure}
          </Text>
          <Text style={styles.contentText}>
            Exams: {client.exams && client.exams.join(', ')}
          </Text>
        </View>
        <View style={styles.ButtonsView}>
          <TouchableOpacity onPress={() => backHandle()} style={styles.button}>
            <Text style={styles.buttonText}>Back</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => deleteUser()}
            style={[styles.button, {}]}>
            <Text style={styles.buttonText}>Finally</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Home;
