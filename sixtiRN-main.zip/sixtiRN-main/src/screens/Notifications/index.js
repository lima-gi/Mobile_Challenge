import {useNavigation} from '@react-navigation/native';
import React, {useState, useContext, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
  FlatList,
} from 'react-native';

import UserContext from '../../context/UserContext/type';
import styles from './styles';

import AsyncStorage from '@react-native-community/async-storage';

import clients from '../../json/clients.json';
import doctors from '../../json/doctor.json';

const Notifications = () => {
  const userCtx = useContext(UserContext);

  const [client, setClient] = useState({});

  const {navigate} = useNavigation();

  const backHandle = async () => {
    navigate('Login');
    userCtx.clearName();
  };

  useEffect(() => {
    const userProfile = async () => {
      const clientId = await AsyncStorage.getItem('clientId');

      const clientObject = clients.data.find(item => item.id === clientId);

      setClient(clientObject);
    };

    userProfile();
  }, []);

  return (
    <SafeAreaView style={styles.backgroundStyle}>
      <View style={styles.view}>
        <FlatList
          style={{width: '100%'}}
          data={client.notifications}
          keyExtractor={item => item.id}
          renderItem={({item}) => {
            const doctor = doctors.data.find(
              itemDoctors => itemDoctors.id === item.doctor,
            );
            return (
              <View style={styles.boxNotifications}>
                <Text style={styles.titleNotifications}>{item.message}</Text>
                <Text style={styles.subtitleNotifications}>{doctor.name}</Text>
              </View>
            );
          }}
        />
      </View>
    </SafeAreaView>
  );
};

export default Notifications;
