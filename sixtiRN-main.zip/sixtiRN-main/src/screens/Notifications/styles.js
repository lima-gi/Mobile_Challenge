import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  backgroundStyle: {
    backgroundColor: '#E2E1E1',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 40,
    color: 'black',
  },
  view: {
    flex: 1,
    alignItems: 'center',
    width: '100%',
    padding: 20,
  },
  boxNotifications: {
    width: '100%',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    marginBottom: 12,
  },
  titleNotifications: {
    fontSize: 16,
    marginBottom: 8,
  },
});

export default styles;
