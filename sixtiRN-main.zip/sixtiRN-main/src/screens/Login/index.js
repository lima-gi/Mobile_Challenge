import {useNavigation} from '@react-navigation/native';
import React, {useState, useContext} from 'react';
import {
  Text,
  TouchableOpacity,
  View,
  TextInput,
  KeyboardAvoidingView,
} from 'react-native';

import UserContext from '../../context/UserContext/type';
import styles from './styles';

import AsyncStorage from '@react-native-community/async-storage';

import clients from '../../json/clients.json';

const Login = () => {
  const userCtx = useContext(UserContext);
  const [cpf, setCpf] = useState('');
  const [id, setId] = useState('');

  const {navigate} = useNavigation();

  function isValidCPF(cpf) {
    if (typeof cpf !== 'string') {
      return false;
    }
    cpf = cpf.replace(/[\s.-]*/gim, '');
    if (
      !cpf ||
      cpf.length != 11 ||
      cpf == '00000000000' ||
      cpf == '11111111111' ||
      cpf == '22222222222' ||
      cpf == '33333333333' ||
      cpf == '44444444444' ||
      cpf == '55555555555' ||
      cpf == '66666666666' ||
      cpf == '77777777777' ||
      cpf == '88888888888' ||
      cpf == '99999999999'
    ) {
      return false;
    }
    var sum = 0;
    var rest;
    for (var i = 1; i <= 9; i++) {
      sum = sum + parseInt(cpf.substring(i - 1, i)) * (11 - i);
    }
    rest = (sum * 10) % 11;
    if (rest == 10 || rest == 11) {
      rest = 0;
    }
    if (rest != parseInt(cpf.substring(9, 10))) {
      return false;
    }
    sum = 0;
    for (var i = 1; i <= 10; i++) {
      sum = sum + parseInt(cpf.substring(i - 1, i)) * (12 - i);
    }
    rest = (sum * 10) % 11;
    if (rest == 10 || rest == 11) {
      rest = 0;
    }
    if (rest != parseInt(cpf.substring(10, 11))) {
      return false;
    }
    return true;
  }

  const handleLogin = async () => {
    const cpfIsValid = isValidCPF(cpf);
    const idExists = clients.data.find(item => item.id === id);

    if (!cpfIsValid) {
      return alert('CPF is not valid!');
    }

    if (!idExists) {
      return alert('Id not exists!');
    }

    const userExists = userCtx.user.find(item => item.cpf === cpf);

    if (!userExists) {
      return alert('User not found!');
    }

    const login = userCtx.user.find(item => item.id === id && item.cpf === cpf);

    if (login) {
      try {
        await AsyncStorage.setItem('clientId', id, null);
        await AsyncStorage.setItem('cpfUser', cpf, null);
        navigate('ClientTabs');
      } catch (error) {
        console.log(error);
      }
    } else {
      return alert('User not have access!');
    }
  };

  return (
    <KeyboardAvoidingView style={{height: '100%'}}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.logo}>Sixti</Text>
        </View>
        <View style={styles.content}>
          <View style={styles.topContent}>
            <Text style={styles.title}>Login</Text>

            <TouchableOpacity onPress={() => navigate('CreateNewMatch')}>
              <Text style={styles.topLink}>Create new match</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.doubleInputView}>
            <TextInput
              style={styles.inputOnlyTopBorderRadius}
              placeholder="CPF"
              placeholderTextColor="#c1bccc"
              onChangeText={user => setCpf(user)}
            />
            <TextInput
              style={styles.inputOnlyBottomBorderRadius}
              placeholder="ID"
              placeholderTextColor="#c1bccc"
              onChangeText={id => setId(id)}
              secureTextEntry={true}
            />
          </View>
          <TouchableOpacity onPress={() => navigate('AlterClientValue')}>
            <View style={styles.footerContainer}>
              <Text style={styles.linkForgotPassword}>Alter client access</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleLogin()}
            style={styles.buttonSubmit}>
            <Text style={styles.buttonText}>Join</Text>
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

export default Login;
