import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E2E1E1',
    height: '100%',
    alignItems: 'center',
  },
  header: {
    backgroundColor: '#89EAFF',
    justifyContent: 'center',
    alignItems: 'center',
    height: '40%',
    width: '100%',
  },
  logo: {
    color: '#000000',
    fontWeight: '600',
    fontSize: 40,
  },
  content: {
    padding: 24,
    height: '60%',
    width: '100%',
  },
  topContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    color: '#32264D',
    fontSize: 24,
    fontWeight: '600',
  },
  topLink: {
    color: '#DE0C4B',
    fontSize: 14,
    textDecorationLine: 'underline',
    textDecorationColor: '#DE0C4B',
  },
  doubleInputView: {
    marginTop: 24,
    justifyContent: 'center',
    width: '100%',
  },

  inputOnlyTopBorderRadius: {
    height: 60,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 12,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    marginBottom: 1,
  },
  input: {
    height: 60,
    backgroundColor: '#ffffff',
    padding: 12,
    marginBottom: 1,
  },
  inputOnlyBottomBorderRadius: {
    height: 60,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 12,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
    marginBottom: 20,
  },
  footerContainer: {
    flexDirection: 'row',
    alignContent: 'center',
    justifyContent: 'center',
    marginVertical: 20,
  },
  linkForgotPassword: {
    color: '#de0c4b',
    fontSize: 14,

    textDecorationLine: 'underline',
    textDecorationColor: '#de0c4b',
  },

  buttonSubmit: {
    backgroundColor: '#de0c4b',
    padding: 20,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },

  buttonText: {
    fontWeight: '600',
    color: '#ffffff',
    fontSize: 16,
  },
  containerContentView: {
    width: '100%',
    padding: 20,
  },
});

export default styles;
